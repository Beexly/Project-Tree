CRC Sales Pack
1. CRC_ONE_PAGER.md
2. NDA_EXTRACT_PROTOCOL.md before real data
3. Synthetic CSVs only
4. No ROI claims. No sports.
